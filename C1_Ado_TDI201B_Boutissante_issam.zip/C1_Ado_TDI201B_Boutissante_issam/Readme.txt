J'ai utiliser le file Config et j'ai ajouter connectionString

mais je sais pas pourquoi la Class ConfigurationManager 
et qu'on je veut importer System.Configuration l'intellej se bloque

Merci Monsieur
